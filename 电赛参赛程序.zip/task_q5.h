#ifndef TASK_Q5_H
#define TASK_Q5_H

#include <stdbool.h>
#include <stdint.h>

typedef struct {
    uint16_t ramp_ms;
    uint8_t base_duty;
    bool decelerating;
    bool detected_a;
} TaskQ5State;

void task_q5_reset(TaskQ5State *state);
bool task_q5_update(TaskQ5State *state, uint8_t active_count,
    int32_t distance_count, uint16_t elapsed_ms);
bool task_q5_update_at_a(TaskQ5State *state, uint8_t active_count,
    int32_t distance_count, uint16_t elapsed_ms);

#endif
