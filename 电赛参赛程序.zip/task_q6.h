#ifndef TASK_Q6_H
#define TASK_Q6_H

#include <stdbool.h>
#include <stdint.h>

typedef enum {
    Q6_IDLE = 0,
    Q6_WAIT_CAPTURE,
    Q6_RUNNING,
    Q6_WAIT_STOP,
    Q6_DONE,
    Q6_FAULT
} Q6State;

typedef enum {
    TASK_Q6_EVENT_NONE = 0,
    TASK_Q6_EVENT_READY,
    TASK_Q6_EVENT_DONE,
    TASK_Q6_EVENT_FAULT
} TaskQ6Event;

typedef enum {
    TASK_Q6_FAULT_NONE = 0,
    TASK_Q6_FAULT_LOCK_FAIL
} TaskQ6Fault;

typedef struct {
    Q6State state;
    TaskQ6Fault fault;
    uint32_t last_start_tx_ms;
    uint8_t start_attempts;
    int16_t target_x10;
    uint16_t max_error_x10;
    bool stop_sent;
} TaskQ6State;

void task_q6_reset(TaskQ6State *state);
void task_q6_start(TaskQ6State *state);
TaskQ6Event task_q6_update(TaskQ6State *state, uint32_t elapsed_ms);
void task_q6_stop(TaskQ6State *state);
bool task_q6_chassis_allowed(const TaskQ6State *state);

#endif
