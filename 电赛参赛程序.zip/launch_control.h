#ifndef LAUNCH_CONTROL_H
#define LAUNCH_CONTROL_H

#include <stdint.h>

typedef struct {
    uint16_t ramp_ms;
    uint8_t normal_frames;
    uint8_t correction_scale_percent;
} LaunchControlState;

void launch_control_reset(LaunchControlState *state);
uint8_t launch_control_update(LaunchControlState *state,
    uint8_t active_count, uint16_t elapsed_ms);

#endif
