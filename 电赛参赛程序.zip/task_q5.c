#include "task_q5.h"

#include "app_config.h"

void task_q5_reset(TaskQ5State *state)
{
    *state = (TaskQ5State) {0};
    state->base_duty = Q5_START_DUTY_PERCENT;
}

static bool task_q5_update_internal(TaskQ5State *state,
    uint8_t active_count, int32_t distance_count, uint16_t elapsed_ms,
    bool allow_distance_failsafe)
{
    if (!state->decelerating &&
        (((distance_count >= Q5_A_DETECT_ARM_COUNTS) &&
             (active_count >= Q5_CROSS_ACTIVE_MIN)) ||
            (allow_distance_failsafe &&
             (distance_count >= Q5_FAILSAFE_DECEL_COUNTS)))) {
        state->decelerating = true;
        state->detected_a = active_count >= Q5_CROSS_ACTIVE_MIN;
        state->ramp_ms = 0U;
    }

    state->ramp_ms += elapsed_ms;
    if (state->decelerating) {
        if ((state->ramp_ms >= Q5_DECEL_STEP_MS) &&
            (state->base_duty > Q5_DECEL_END_DUTY_PERCENT)) {
            state->ramp_ms = 0U;
            state->base_duty =
                (state->base_duty > Q5_DECEL_STEP_PERCENT)
                ? (uint8_t) (state->base_duty - Q5_DECEL_STEP_PERCENT)
                : 0U;
        }
        return state->base_duty <= Q5_DECEL_END_DUTY_PERCENT;
    }

    if ((state->ramp_ms >= Q5_RAMP_STEP_MS) &&
        (state->base_duty < Q5_BASE_DUTY_PERCENT)) {
        state->ramp_ms = 0U;
        state->base_duty += Q5_RAMP_STEP_PERCENT;
        if (state->base_duty > Q5_BASE_DUTY_PERCENT) {
            state->base_duty = Q5_BASE_DUTY_PERCENT;
        }
    }
    return false;
}

bool task_q5_update(TaskQ5State *state, uint8_t active_count,
    int32_t distance_count, uint16_t elapsed_ms)
{
    return task_q5_update_internal(state, active_count, distance_count,
        elapsed_ms, true);
}

bool task_q5_update_at_a(TaskQ5State *state, uint8_t active_count,
    int32_t distance_count, uint16_t elapsed_ms)
{
    return task_q5_update_internal(state, active_count, distance_count,
        elapsed_ms, false);
}
