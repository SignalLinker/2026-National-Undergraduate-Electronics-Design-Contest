#include "task_q4.h"

#include "app_config.h"
#include "encoder.h"

void task_q4_reset(TaskQ4State *state)
{
    state->ramp_ms = 0U;
    state->base_duty = Q4_START_DUTY_PERCENT;
    state->decelerating = false;
}

bool task_q4_update(TaskQ4State *state, uint16_t elapsed_ms)
{
    if (!state->decelerating &&
        (encoder_average_abs_count() >= Q4_DECEL_START_COUNTS)) {
        state->decelerating = true;
        state->ramp_ms = 0U;
    }

    state->ramp_ms += elapsed_ms;
    if (state->decelerating) {
        if (state->ramp_ms >= Q4_DECEL_STEP_MS) {
            state->ramp_ms = 0U;
            if (state->base_duty > Q4_DECEL_END_DUTY_PERCENT) {
                state->base_duty =
                    (state->base_duty > Q4_DECEL_STEP_PERCENT)
                    ? (uint8_t) (state->base_duty - Q4_DECEL_STEP_PERCENT)
                    : 0U;
            }
        }
        return state->base_duty <= Q4_DECEL_END_DUTY_PERCENT;
    }

    if ((state->ramp_ms >= Q4_RAMP_STEP_MS) &&
        (state->base_duty < Q4_BASE_DUTY_PERCENT)) {
        state->ramp_ms = 0U;
        state->base_duty += Q4_RAMP_STEP_PERCENT;
        if (state->base_duty > Q4_BASE_DUTY_PERCENT) {
            state->base_duty = Q4_BASE_DUTY_PERCENT;
        }
    }
    return false;
}
