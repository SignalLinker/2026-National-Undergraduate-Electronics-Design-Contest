#include "button.h"

#include <stdbool.h>

#include "ti_msp_dl_config.h"

#define BUTTON_DEBOUNCE_MS 20U
#define BUTTON_LONG_PRESS_MS 800U

static bool button_is_pressed(ButtonId id)
{
    uint32_t pin = (id == BUTTON_ID_SELECT) ? GPIO_KEYS_SELECT_KEY_PIN :
        GPIO_KEYS_USER_KEY_PIN;

    return DL_GPIO_readPins(GPIO_KEYS_PORT, pin) == 0U;
}

void button_state_init(ButtonState *state)
{
    *state = (ButtonState) {0};
}

ButtonEvent button_update_10ms(ButtonState *state, ButtonId id,
    uint16_t *hold_ms)
{
    bool raw_pressed = button_is_pressed(id);

    if (raw_pressed != state->previous_raw) {
        state->previous_raw = raw_pressed;
        state->debounce_ms = 0U;
    } else if (state->debounce_ms < BUTTON_DEBOUNCE_MS) {
        state->debounce_ms += 10U;
    }

    if ((state->debounce_ms >= BUTTON_DEBOUNCE_MS) &&
        (state->stable_pressed != raw_pressed)) {
        state->stable_pressed = raw_pressed;
        if (!state->stable_pressed) {
            uint16_t released_ms = state->pressed_ms;
            state->pressed_ms = 0U;
            *hold_ms = released_ms;
            if (released_ms >= BUTTON_LONG_PRESS_MS) {
                return BUTTON_EVENT_LONG;
            }
            if (released_ms >= 50U) {
                return BUTTON_EVENT_SHORT;
            }
        }
    }

    if (state->stable_pressed && (state->pressed_ms < 60000U)) {
        state->pressed_ms += 10U;
    }
    *hold_ms = state->pressed_ms;
    return BUTTON_EVENT_NONE;
}
