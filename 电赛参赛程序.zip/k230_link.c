#include "k230_link.h"

#include <stdbool.h>
#include <stdint.h>

#include "ti_msp_dl_config.h"

#define K230_FRAME_HEAD1 0xA5U
#define K230_FRAME_HEAD2 0x5AU
#define K230_FRAME_LENGTH 8U
#define K230_TYPE_START_TASK 0x10U
#define K230_TYPE_STOP_TASK 0x11U
#define K230_TYPE_STATUS 0x20U
#define K230_TASK_MIN 0x03U
#define K230_TASK_MAX 0x06U

static uint8_t g_rx_frame[K230_FRAME_LENGTH];
static uint8_t g_rx_index;

static uint8_t frame_checksum(const uint8_t *frame)
{
    uint8_t checksum = 0U;
    uint8_t index;

    for (index = 0U; index < (K230_FRAME_LENGTH - 1U); index++) {
        checksum ^= frame[index];
    }
    return checksum;
}

static bool parse_byte(uint8_t value, K230StatusFrame *status)
{
    if (g_rx_index == 0U) {
        if (value == K230_FRAME_HEAD1) {
            g_rx_frame[0] = value;
            g_rx_index = 1U;
        }
        return false;
    }

    if (g_rx_index == 1U) {
        if (value == K230_FRAME_HEAD2) {
            g_rx_frame[1] = value;
            g_rx_index = 2U;
        } else if (value != K230_FRAME_HEAD1) {
            g_rx_index = 0U;
        }
        return false;
    }

    g_rx_frame[g_rx_index++] = value;
    if (g_rx_index < K230_FRAME_LENGTH) {
        return false;
    }
    g_rx_index = 0U;

    if ((frame_checksum(g_rx_frame) != g_rx_frame[7]) ||
        (g_rx_frame[2] != K230_TYPE_STATUS) ||
        (g_rx_frame[3] > K230_STATE_CAR_ONLY)) {
        return false;
    }

    status->state = g_rx_frame[3];
    status->valid = g_rx_frame[4] != 0U;
    status->position_x10_cm = (int16_t) g_rx_frame[5] - 128;
    status->elapsed_ms = (uint16_t) g_rx_frame[6] * 100U;
    return true;
}

void k230_link_reset(void)
{
    g_rx_index = 0U;
    while (!DL_UART_Main_isRXFIFOEmpty(UART_K230_INST)) {
        (void) DL_UART_Main_receiveData(UART_K230_INST);
    }
}

void k230_link_send_task_start(uint8_t task_number)
{
    uint8_t frame[] = {
        K230_FRAME_HEAD1,
        K230_FRAME_HEAD2,
        K230_TYPE_START_TASK,
        task_number,
        0U,
        0U,
        0U,
        0U,
    };
    uint8_t index;

    if ((task_number < K230_TASK_MIN) || (task_number > K230_TASK_MAX)) {
        return;
    }

    frame[7] = frame_checksum(frame);
    for (index = 0U; index < (uint8_t) sizeof(frame); index++) {
        DL_UART_Main_transmitDataBlocking(UART_K230_INST, frame[index]);
    }
}

void k230_link_send_q3_start(void)
{
    k230_link_send_task_start(3U);
}

void k230_link_send_stop(void)
{
    uint8_t frame[] = {
        K230_FRAME_HEAD1,
        K230_FRAME_HEAD2,
        K230_TYPE_STOP_TASK,
        0U,
        0U,
        0U,
        0U,
        0U,
    };
    uint8_t index;

    frame[7] = frame_checksum(frame);
    for (index = 0U; index < (uint8_t) sizeof(frame); index++) {
        DL_UART_Main_transmitDataBlocking(UART_K230_INST, frame[index]);
    }
}

bool k230_link_poll_status(K230StatusFrame *status)
{
    while (!DL_UART_Main_isRXFIFOEmpty(UART_K230_INST)) {
        if (parse_byte(
                (uint8_t) DL_UART_Main_receiveData(UART_K230_INST), status)) {
            return true;
        }
    }
    return false;
}
