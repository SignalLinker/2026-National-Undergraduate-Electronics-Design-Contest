#include "task_q2.h"

#include "app_config.h"

#define Q2_CROSS_ACTIVE_MIN 5U
#define Q2_NORMAL_MIN 1U
#define Q2_NORMAL_MAX 3U
#define Q2_NORMAL_FRAMES 3U

void task_q2_reset(TaskQ2State *state)
{
    *state = (TaskQ2State) {0};
    state->base_duty = Q2_BASE_DUTY_PERCENT;
}

bool task_q2_update(TaskQ2State *state, uint8_t active_count,
    int32_t distance_count, uint16_t elapsed_ms)
{
    if (!state->ready) {
        if ((active_count >= Q2_NORMAL_MIN) &&
            (active_count <= Q2_NORMAL_MAX)) {
            if (state->normal_frames < Q2_NORMAL_FRAMES) {
                state->normal_frames++;
            }
        } else {
            state->normal_frames = 0U;
        }
        state->ready = state->normal_frames >= Q2_NORMAL_FRAMES;
        return false;
    }

    if (!state->approaching_a &&
        (distance_count >= Q2_APPROACH_START_COUNTS)) {
        state->approaching_a = true;
        state->decel_ms = 0U;
    }

    if (!state->approaching_a) {
        return false;
    }

    state->decel_ms += elapsed_ms;
    if ((state->decel_ms >= Q2_DECEL_STEP_MS) &&
        (state->base_duty > Q2_APPROACH_DUTY_PERCENT)) {
        state->decel_ms = 0U;
        state->base_duty =
            (state->base_duty > Q2_DECEL_STEP_PERCENT)
            ? (uint8_t) (state->base_duty - Q2_DECEL_STEP_PERCENT)
            : 0U;
        if (state->base_duty < Q2_APPROACH_DUTY_PERCENT) {
            state->base_duty = Q2_APPROACH_DUTY_PERCENT;
        }
    }

    return (active_count >= Q2_CROSS_ACTIVE_MIN) ||
        (distance_count >= Q2_FAILSAFE_STOP_COUNTS);
}
