#ifndef OLED_H
#define OLED_H

#include <stdbool.h>
#include <stdint.h>

bool oled_init(void);
void oled_clear_line(uint8_t page);
void oled_print(uint8_t page, uint8_t column, const char *text);

#endif
