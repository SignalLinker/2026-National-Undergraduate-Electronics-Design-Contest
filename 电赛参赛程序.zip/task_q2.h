#ifndef TASK_Q2_H
#define TASK_Q2_H

#include <stdbool.h>
#include <stdint.h>

typedef struct {
    uint8_t normal_frames;
    uint8_t base_duty;
    uint16_t decel_ms;
    bool ready;
    bool approaching_a;
} TaskQ2State;

void task_q2_reset(TaskQ2State *state);
bool task_q2_update(TaskQ2State *state, uint8_t active_count,
    int32_t distance_count, uint16_t elapsed_ms);

#endif
