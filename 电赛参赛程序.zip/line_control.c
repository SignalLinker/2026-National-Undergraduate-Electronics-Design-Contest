#include "line_control.h"

#include "motor.h"

static uint8_t clamp_duty(int16_t duty, uint8_t maximum)
{
    if (duty < 0) {
        return 0U;
    }
    if (duty > maximum) {
        return maximum;
    }
    return (uint8_t) duty;
}

static int16_t slew_correction(int16_t current, int16_t target,
    uint8_t maximum_step)
{
    int16_t step = (int16_t) maximum_step;

    if ((maximum_step == 0U) || (current == target)) {
        return target;
    }
    if (current < target) {
        return ((target - current) <= step) ? target : (int16_t) (current + step);
    }
    return ((current - target) <= step) ? target : (int16_t) (current - step);
}

void line_control_reset(LineControlState *state)
{
    *state = (LineControlState) {0};
}

static int16_t line_control_curve_correction(LineControlState *state,
    int16_t target, const LineControlConfig *config)
{
    if (!state->curve_active) {
        if (target == 0) {
            state->correction_percent = 0;
            return 0;
        }
        state->curve_active = true;
        state->neutral_frames = 0U;
        state->correction_percent = target;
        return target;
    }

    if (target != 0) {
        state->neutral_frames = 0U;
        state->correction_percent = slew_correction(
            state->correction_percent, target,
            config->curve_correction_step_percent);
        return state->correction_percent;
    }

    if (state->neutral_frames < config->curve_exit_frames) {
        state->neutral_frames++;
    }
    if ((config->curve_exit_frames == 0U) ||
        (state->neutral_frames >= config->curve_exit_frames)) {
        line_control_reset(state);
        return 0;
    }
    state->correction_percent = slew_correction(state->correction_percent,
        0, config->curve_correction_step_percent);
    return state->correction_percent;
}

void line_control_apply(LineControlState *state, bool run, bool has_line,
    int16_t error,
    uint8_t base_duty, uint8_t correction_scale_percent,
    const LineControlConfig *config, uint8_t *left_duty,
    uint8_t *right_duty)
{
    int32_t scaled_correction;
    int16_t target_correction;
    int16_t applied_correction;

    *left_duty = 0U;
    *right_duty = 0U;
    if (!run || !has_line || (error == 99)) {
        line_control_reset(state);
        motor_stop();
        return;
    }

    if (correction_scale_percent > 100U) {
        correction_scale_percent = 100U;
    }
    if ((error >= -(int16_t) config->error_deadband) &&
        (error <= (int16_t) config->error_deadband)) {
        target_correction = 0;
    } else {
        scaled_correction = (int32_t) error * config->kp_percent *
            correction_scale_percent;
        target_correction = (int16_t) (scaled_correction / 100);
    }
    applied_correction = line_control_curve_correction(state,
        target_correction, config);
    *left_duty = clamp_duty((int16_t) base_duty +
            config->left_trim_percent + applied_correction,
        config->maximum_duty);
    *right_duty = clamp_duty((int16_t) base_duty +
            config->right_trim_percent - applied_correction,
        config->maximum_duty);
    motor_drive_forward(*left_duty, *right_duty);
}
