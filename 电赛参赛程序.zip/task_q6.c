#include "task_q6.h"

#include "app_config.h"
#include "k230_link.h"

static uint16_t abs_x10_delta(int16_t left, int16_t right)
{
    int16_t delta = left - right;
    if (delta < 0) {
        delta = (int16_t) -delta;
    }
    return (uint16_t) delta;
}

static void task_q6_enter_fault(TaskQ6State *state, TaskQ6Fault fault)
{
    state->state = Q6_FAULT;
    state->fault = fault;
    if (!state->stop_sent) {
        k230_link_send_stop();
        state->stop_sent = true;
    }
}

static TaskQ6Event task_q6_handle_status(TaskQ6State *state,
    const K230StatusFrame *status)
{
    uint16_t error_x10;

    if (status->state == K230_STATE_ABORTED) {
        if (state->state == Q6_WAIT_STOP) {
            state->state = Q6_DONE;
            return TASK_Q6_EVENT_DONE;
        }
        return TASK_Q6_EVENT_NONE;
    }

    if (state->state == Q6_WAIT_CAPTURE) {
        if ((status->state == K230_STATE_HOLD_TARGET) && status->valid) {
            state->target_x10 = status->position_x10_cm;
            state->max_error_x10 = 0U;
            state->state = Q6_RUNNING;
            return TASK_Q6_EVENT_READY;
        }
        return TASK_Q6_EVENT_NONE;
    }

    if ((state->state == Q6_RUNNING) &&
        (status->state == K230_STATE_HOLD_TARGET) && status->valid) {
        error_x10 = abs_x10_delta(status->position_x10_cm, state->target_x10);
        if (error_x10 > state->max_error_x10) {
            state->max_error_x10 = error_x10;
        }
    }

    return TASK_Q6_EVENT_NONE;
}

void task_q6_reset(TaskQ6State *state)
{
    *state = (TaskQ6State) {0};
    state->state = Q6_IDLE;
}

void task_q6_start(TaskQ6State *state)
{
    task_q6_reset(state);
    k230_link_reset();
    k230_link_send_task_start(6U);
    state->state = Q6_WAIT_CAPTURE;
    state->start_attempts = 1U;
    state->last_start_tx_ms = 0U;
}

TaskQ6Event task_q6_update(TaskQ6State *state, uint32_t elapsed_ms)
{
    K230StatusFrame status;
    TaskQ6Event event = TASK_Q6_EVENT_NONE;

    while (k230_link_poll_status(&status)) {
        event = task_q6_handle_status(state, &status);
        if ((event == TASK_Q6_EVENT_READY) ||
            (event == TASK_Q6_EVENT_DONE) ||
            (event == TASK_Q6_EVENT_FAULT)) {
            return event;
        }
    }

    if (state->state == Q6_WAIT_CAPTURE) {
        if ((state->start_attempts < Q6_START_MAX_ATTEMPTS) &&
            ((uint32_t) (elapsed_ms - state->last_start_tx_ms) >=
                Q6_START_RETRY_MS)) {
            k230_link_send_task_start(6U);
            state->start_attempts++;
            state->last_start_tx_ms = elapsed_ms;
        }
    }

    if (state->state == Q6_WAIT_CAPTURE) {
        if (elapsed_ms >= Q6_CAPTURE_TIMEOUT_MS) {
            task_q6_enter_fault(state, TASK_Q6_FAULT_LOCK_FAIL);
            return TASK_Q6_EVENT_FAULT;
        }
    }

    return event;
}

void task_q6_stop(TaskQ6State *state)
{
    if (!state->stop_sent) {
        k230_link_send_stop();
        state->stop_sent = true;
    }
    state->state = Q6_WAIT_STOP;
}

bool task_q6_chassis_allowed(const TaskQ6State *state)
{
    return state->state == Q6_RUNNING;
}
