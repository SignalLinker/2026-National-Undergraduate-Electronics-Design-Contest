#ifndef LINE_CONTROL_H
#define LINE_CONTROL_H

#include <stdbool.h>
#include <stdint.h>

typedef struct {
    uint8_t maximum_duty;
    uint8_t error_deadband;
    uint8_t curve_correction_step_percent;
    uint8_t curve_exit_frames;
    int8_t kp_percent;
    int8_t left_trim_percent;
    int8_t right_trim_percent;
} LineControlConfig;

typedef struct {
    int16_t correction_percent;
    uint8_t neutral_frames;
    bool curve_active;
} LineControlState;

void line_control_reset(LineControlState *state);
void line_control_apply(LineControlState *state, bool run, bool has_line,
    int16_t error,
    uint8_t base_duty, uint8_t correction_scale_percent,
    const LineControlConfig *config, uint8_t *left_duty,
    uint8_t *right_duty);

#endif
