#include "motor.h"

#include "app_config.h"
#include "ti_msp_dl_config.h"

static uint32_t pwm_compare_from_percent(uint8_t duty_percent)
{
    if (duty_percent > 100U) {
        duty_percent = 100U;
    }
    return (PWM_PERIOD_COUNTS * (100U - duty_percent)) / 100U;
}

static void motor_pwm_set(uint8_t left_duty, uint8_t right_duty)
{
    DL_TimerG_setCaptureCompareValue(PWM_MOTOR_INST,
        pwm_compare_from_percent(left_duty), GPIO_PWM_MOTOR_C0_IDX);
    DL_TimerG_setCaptureCompareValue(PWM_MOTOR_INST,
        pwm_compare_from_percent(right_duty), GPIO_PWM_MOTOR_C1_IDX);
}

static void motor_set_forward_direction(void)
{
    DL_GPIO_clearPins(GPIOB, GPIO_MOTOR_DIR_AIN1_PIN);
    DL_GPIO_setPins(GPIOB, GPIO_MOTOR_DIR_AIN2_PIN);
    DL_GPIO_clearPins(GPIOA, GPIO_MOTOR_DIR_BIN1_PIN);
    DL_GPIO_setPins(GPIOB, GPIO_MOTOR_DIR_BIN2_PIN);
}

void motor_stop(void)
{
    motor_pwm_set(0U, 0U);
    DL_GPIO_clearPins(GPIOB,
        GPIO_MOTOR_DIR_AIN1_PIN | GPIO_MOTOR_DIR_AIN2_PIN |
            GPIO_MOTOR_DIR_BIN2_PIN);
    DL_GPIO_clearPins(GPIOA, GPIO_MOTOR_DIR_BIN1_PIN);
}

void motor_drive_forward(uint8_t left_duty, uint8_t right_duty)
{
    motor_set_forward_direction();
    motor_pwm_set(left_duty, right_duty);
}

void motor_short_brake(uint8_t duty_percent, uint32_t brake_ms)
{
    DL_GPIO_setPins(GPIOB,
        GPIO_MOTOR_DIR_AIN1_PIN | GPIO_MOTOR_DIR_AIN2_PIN |
            GPIO_MOTOR_DIR_BIN2_PIN);
    DL_GPIO_setPins(GPIOA, GPIO_MOTOR_DIR_BIN1_PIN);
    motor_pwm_set(duty_percent, duty_percent);
    delay_cycles((CPUCLK_FREQ / 1000U) * brake_ms);
    motor_stop();
}

void motor_soft_stop(uint8_t left_duty, uint8_t right_duty,
    uint8_t step_percent, uint32_t step_ms, uint8_t brake_duty,
    uint32_t brake_ms)
{
    motor_set_forward_direction();
    while ((left_duty > 0U) || (right_duty > 0U)) {
        left_duty = (left_duty > step_percent)
                        ? (uint8_t) (left_duty - step_percent)
                        : 0U;
        right_duty = (right_duty > step_percent)
                         ? (uint8_t) (right_duty - step_percent)
                         : 0U;
        motor_pwm_set(left_duty, right_duty);
        delay_cycles((CPUCLK_FREQ / 1000U) * step_ms);
    }
    motor_short_brake(brake_duty, brake_ms);
}
