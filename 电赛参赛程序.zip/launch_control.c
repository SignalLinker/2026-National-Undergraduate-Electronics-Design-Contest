#include "launch_control.h"

#include "app_config.h"

void launch_control_reset(LaunchControlState *state)
{
    *state = (LaunchControlState) {0};
}

uint8_t launch_control_update(LaunchControlState *state,
    uint8_t active_count, uint16_t elapsed_ms)
{
    if (state->normal_frames < LAUNCH_NORMAL_FRAMES) {
        if ((active_count >= LAUNCH_NORMAL_MIN) &&
            (active_count <= LAUNCH_NORMAL_MAX)) {
            state->normal_frames++;
        } else {
            state->normal_frames = 0U;
        }
        return 0U;
    }

    state->ramp_ms += elapsed_ms;
    if ((state->ramp_ms >= LAUNCH_CORRECTION_STEP_MS) &&
        (state->correction_scale_percent < 100U)) {
        state->ramp_ms = 0U;
        state->correction_scale_percent +=
            LAUNCH_CORRECTION_STEP_PERCENT;
        if (state->correction_scale_percent > 100U) {
            state->correction_scale_percent = 100U;
        }
    }
    return state->correction_scale_percent;
}
