#include "ti_msp_dl_config.h"

#include "app_config.h"
#include "button.h"
#include "encoder.h"
#include "motor.h"
#include "oled.h"
#include "task_manager.h"
#include "timebase.h"

int main(void)
{
    uint16_t start_hold_ms = 0U;
    uint16_t select_hold_ms = 0U;
    uint16_t display_ms = 0U;
    ButtonEvent start_event;
    ButtonEvent select_event;
    ButtonState start_button;
    ButtonState select_button;
    TaskManager manager;

    SYSCFG_DL_init();
    timebase_init();
    motor_stop();
    encoder_init();
    __enable_irq();

    if (!oled_init()) {
        motor_stop();
        while (1) {
            delay_cycles(CPUCLK_FREQ / 10U);
        }
    }

    task_manager_init(&manager);
    button_state_init(&start_button);
    button_state_init(&select_button);
    task_manager_render(&manager);

    while (1) {
        start_event = button_update_10ms(&start_button, BUTTON_ID_START,
            &start_hold_ms);
        select_event = button_update_10ms(&select_button, BUTTON_ID_SELECT,
            &select_hold_ms);
        task_manager_handle_buttons(&manager, select_event, start_event);
        task_manager_update(&manager, APP_TICK_MS);

        display_ms += APP_TICK_MS;
        if (display_ms >= DISPLAY_UPDATE_MS) {
            display_ms = 0U;
            task_manager_render(&manager);
        }

        delay_cycles((CPUCLK_FREQ / 1000U) * APP_TICK_MS);
    }
}
