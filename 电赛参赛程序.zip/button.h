#ifndef BUTTON_H
#define BUTTON_H

#include <stdbool.h>
#include <stdint.h>

typedef enum {
    BUTTON_ID_START = 0,
    BUTTON_ID_SELECT,
} ButtonId;

typedef enum {
    BUTTON_EVENT_NONE = 0,
    BUTTON_EVENT_SHORT,
    BUTTON_EVENT_LONG,
} ButtonEvent;

typedef struct {
    bool stable_pressed;
    bool previous_raw;
    uint16_t debounce_ms;
    uint16_t pressed_ms;
} ButtonState;

void button_state_init(ButtonState *state);
ButtonEvent button_update_10ms(ButtonState *state, ButtonId id,
    uint16_t *hold_ms);

#endif
