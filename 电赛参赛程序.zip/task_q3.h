#ifndef TASK_Q3_H
#define TASK_Q3_H

#include <stdbool.h>
#include <stdint.h>

typedef enum {
    TASK_Q3_IDLE = 0,
    TASK_Q3_WAIT_DONE,
    TASK_Q3_DONE,
    TASK_Q3_REMOTE_ERROR
} TaskQ3Status;

typedef struct {
    TaskQ3Status status;
    bool ack_received;
    bool status_received;
    uint8_t start_attempts;
    uint32_t last_status_ms;
} TaskQ3State;

void task_q3_reset(TaskQ3State *state);
void task_q3_start(TaskQ3State *state);
void task_q3_cancel(TaskQ3State *state);
TaskQ3Status task_q3_update(TaskQ3State *state, uint32_t elapsed_ms);

#endif
