#include "task_manager.h"

#include "app_config.h"
#include "encoder.h"
#include "k230_link.h"
#include "line_control.h"
#include "motor.h"
#include "oled.h"
#include "timebase.h"

static const LineControlConfig g_q2_line_config = {
    .maximum_duty = Q2_MAX_DUTY_PERCENT,
    .error_deadband = LINE_ERROR_DEADBAND,
    .curve_correction_step_percent = LINE_CURVE_CORRECTION_STEP_PERCENT,
    .curve_exit_frames = LINE_CURVE_EXIT_FRAMES,
    .kp_percent = Q2_KP_PERCENT,
    .left_trim_percent = Q2_LEFT_TRIM_PERCENT,
    .right_trim_percent = Q2_RIGHT_TRIM_PERCENT,
};

static const LineControlConfig g_q4_line_config = {
    .maximum_duty = Q4_MAX_DUTY_PERCENT,
    .error_deadband = LINE_ERROR_DEADBAND,
    .curve_correction_step_percent = LINE_CURVE_CORRECTION_STEP_PERCENT,
    .curve_exit_frames = LINE_CURVE_EXIT_FRAMES,
    .kp_percent = Q4_KP_PERCENT,
    .left_trim_percent = Q4_LEFT_TRIM_PERCENT,
    .right_trim_percent = Q4_RIGHT_TRIM_PERCENT,
};

static const LineControlConfig g_q5_line_config = {
    .maximum_duty = Q5_MAX_DUTY_PERCENT,
    .error_deadband = LINE_ERROR_DEADBAND,
    .curve_correction_step_percent = LINE_CURVE_CORRECTION_STEP_PERCENT,
    .curve_exit_frames = LINE_CURVE_EXIT_FRAMES,
    .kp_percent = Q5_KP_PERCENT,
    .left_trim_percent = Q5_LEFT_TRIM_PERCENT,
    .right_trim_percent = Q5_RIGHT_TRIM_PERCENT,
};

static bool task_mode_is_available(uint8_t mode)
{
    return (mode == TASK_MODE_Q2) || (mode == TASK_MODE_Q3) ||
        (mode == TASK_MODE_Q4) || (mode == TASK_MODE_Q5) ||
        (mode == TASK_MODE_Q6);
}

static void task_stop_output(TaskManager *manager)
{
    manager->left_duty = 0U;
    manager->right_duty = 0U;
    motor_stop();
}

static bool task_mode_is_q5_lap(uint8_t mode)
{
    return (mode == TASK_MODE_Q5) || (mode == TASK_MODE_Q6);
}

static void k230_start_car_ball_task(uint8_t task_number)
{
    k230_link_reset();
    k230_link_send_task_start(task_number);
}

static uint8_t k230_task_number_from_mode(uint8_t mode)
{
    if (mode == TASK_MODE_Q4) {
        return 4U;
    }
    if (mode == TASK_MODE_Q5) {
        return 5U;
    }
    return 0U;
}

static void task_start(TaskManager *manager)
{
    uint8_t k230_task_number;

    if (!task_mode_is_available(manager->selected_mode)) {
        return;
    }

    encoder_reset();
    task_q2_reset(&manager->q2);
    task_q3_reset(&manager->q3);
    task_q4_reset(&manager->q4);
    task_q5_reset(&manager->q5);
    task_q6_reset(&manager->q6);
    launch_control_reset(&manager->launch);
    line_control_reset(&manager->line_control);
    manager->left_duty = 0U;
    manager->right_duty = 0U;
    manager->elapsed_ms = 0U;
    manager->start_ms = timebase_millis();
    manager->finished = false;
    manager->running = true;
    if (manager->selected_mode == TASK_MODE_Q3) {
        motor_stop();
        task_q3_start(&manager->q3);
    } else if (manager->selected_mode == TASK_MODE_Q6) {
        motor_stop();
        task_q6_start(&manager->q6);
    } else {
        k230_task_number = k230_task_number_from_mode(manager->selected_mode);
        if (k230_task_number != 0U) {
            k230_start_car_ball_task(k230_task_number);
        }
    }
}

static void task_emergency_stop(TaskManager *manager)
{
    manager->running = false;
    manager->elapsed_ms = timebase_millis() - manager->start_ms;
    if (manager->selected_mode == TASK_MODE_Q3) {
        task_q3_cancel(&manager->q3);
    } else if (manager->selected_mode == TASK_MODE_Q6) {
        task_q6_stop(&manager->q6);
    }
    motor_short_brake(Q4_HOLD_BRAKE_DUTY_PERCENT, Q4_HOLD_BRAKE_MS);
    task_stop_output(manager);
}

static void task_finish_q2(TaskManager *manager)
{
    manager->running = false;
    motor_short_brake(Q2_BRAKE_DUTY_PERCENT, Q2_BRAKE_MS);
    manager->elapsed_ms = timebase_millis() - manager->start_ms;
    manager->finished = true;
    task_stop_output(manager);
}

static void task_finish_q4(TaskManager *manager)
{
    manager->running = false;
    motor_stop();
    manager->elapsed_ms = timebase_millis() - manager->start_ms;
    manager->finished = true;
    task_stop_output(manager);
}

static void task_finish_q3(TaskManager *manager)
{
    manager->running = false;
    manager->elapsed_ms = timebase_millis() - manager->start_ms;
    manager->finished = true;
    task_stop_output(manager);
}

static void task_fail_remote(TaskManager *manager)
{
    manager->running = false;
    manager->elapsed_ms = timebase_millis() - manager->start_ms;
    manager->finished = false;
    task_stop_output(manager);
}

static void task_finish_q5(TaskManager *manager)
{
    manager->running = false;
    motor_stop();
    if (!manager->q5.detected_a) {
        manager->elapsed_ms = timebase_millis() - manager->start_ms;
    }
    manager->finished = true;
    task_stop_output(manager);
}

static void task_stop_q6_at_a(TaskManager *manager)
{
    motor_stop();
    task_stop_output(manager);
    task_q6_stop(&manager->q6);
}

static void task_finish_q6(TaskManager *manager)
{
    manager->running = false;
    manager->finished = true;
    task_stop_output(manager);
}

void task_manager_init(TaskManager *manager)
{
    *manager = (TaskManager) {0};
    manager->selected_mode = TASK_MODE_Q2;
    manager->active_high = true;
    manager->gray = gray_scan(manager->active_high);
    task_q2_reset(&manager->q2);
    task_q3_reset(&manager->q3);
    task_q4_reset(&manager->q4);
    task_q5_reset(&manager->q5);
    task_q6_reset(&manager->q6);
    launch_control_reset(&manager->launch);
    line_control_reset(&manager->line_control);
}

void task_manager_handle_buttons(TaskManager *manager,
    ButtonEvent select_event, ButtonEvent start_event)
{
    if ((select_event != BUTTON_EVENT_NONE) && !manager->running) {
        manager->selected_mode++;
        if (manager->selected_mode > TASK_MODE_MAX) {
            manager->selected_mode = TASK_MODE_MIN;
        }
        manager->finished = false;
        manager->elapsed_ms = 0U;
        task_q3_reset(&manager->q3);
        task_q6_reset(&manager->q6);
        task_stop_output(manager);
    }

    if (start_event == BUTTON_EVENT_LONG) {
        if (manager->running) {
            task_emergency_stop(manager);
        } else {
            task_start(manager);
        }
    }
}

void task_manager_update(TaskManager *manager, uint16_t elapsed_ms)
{
    uint8_t correction_scale_percent;

    manager->gray = gray_scan(manager->active_high);
    if (!manager->running) {
        return;
    }

    if (!(task_mode_is_q5_lap(manager->selected_mode) &&
            manager->q5.detected_a)) {
        manager->elapsed_ms = timebase_millis() - manager->start_ms;
    }
    if (manager->selected_mode == TASK_MODE_Q3) {
        TaskQ3Status q3_status = task_q3_update(&manager->q3,
            manager->elapsed_ms);
        if (q3_status == TASK_Q3_DONE) {
            task_finish_q3(manager);
        } else if (q3_status == TASK_Q3_REMOTE_ERROR) {
            task_fail_remote(manager);
        }
        return;
    }
    if (manager->selected_mode == TASK_MODE_Q6) {
        TaskQ6Event q6_event = task_q6_update(&manager->q6,
            manager->elapsed_ms);
        if (q6_event == TASK_Q6_EVENT_READY) {
            launch_control_reset(&manager->launch);
            line_control_reset(&manager->line_control);
        } else if (q6_event == TASK_Q6_EVENT_DONE) {
            task_finish_q6(manager);
            return;
        } else if (q6_event == TASK_Q6_EVENT_FAULT) {
            task_fail_remote(manager);
            return;
        }

        if (!task_q6_chassis_allowed(&manager->q6)) {
            task_stop_output(manager);
            return;
        }
    }
    correction_scale_percent = launch_control_update(&manager->launch,
        manager->gray.active_count, elapsed_ms);
    if (manager->selected_mode == TASK_MODE_Q2) {
        if (task_q2_update(&manager->q2, manager->gray.active_count,
                encoder_average_abs_count(), elapsed_ms)) {
            task_finish_q2(manager);
            return;
        }
        line_control_apply(&manager->line_control, true,
            manager->gray.has_line, manager->gray.error,
            manager->q2.base_duty, correction_scale_percent,
            &g_q2_line_config, &manager->left_duty, &manager->right_duty);
        return;
    }

    if (manager->selected_mode == TASK_MODE_Q4) {
        if (task_q4_update(&manager->q4, elapsed_ms)) {
            task_finish_q4(manager);
            return;
        }
        line_control_apply(&manager->line_control, true,
            manager->gray.has_line, manager->gray.error,
            manager->q4.base_duty, correction_scale_percent,
            &g_q4_line_config, &manager->left_duty, &manager->right_duty);
        return;
    }

    if (task_mode_is_q5_lap(manager->selected_mode)) {
        bool should_stop;

        if (manager->selected_mode == TASK_MODE_Q6) {
            should_stop = task_q5_update_at_a(&manager->q5,
                manager->gray.active_count, encoder_average_abs_count(),
                elapsed_ms);
        } else {
            should_stop = task_q5_update(&manager->q5,
                manager->gray.active_count, encoder_average_abs_count(),
                elapsed_ms);
        }
        if (should_stop) {
            if (manager->selected_mode == TASK_MODE_Q6) {
                task_stop_q6_at_a(manager);
                return;
            }
            task_finish_q5(manager);
            return;
        }
        line_control_apply(&manager->line_control, true,
            manager->gray.has_line, manager->gray.error,
            manager->q5.base_duty, correction_scale_percent,
            &g_q5_line_config, &manager->left_duty, &manager->right_duty);
    }
}

static void append_unsigned5(char *buffer, uint8_t *index, uint32_t value)
{
    if (value > 99999U) {
        value = 99999U;
    }
    buffer[(*index)++] = (char) ('0' + ((value / 10000U) % 10U));
    buffer[(*index)++] = (char) ('0' + ((value / 1000U) % 10U));
    buffer[(*index)++] = (char) ('0' + ((value / 100U) % 10U));
    buffer[(*index)++] = (char) ('0' + ((value / 10U) % 10U));
    buffer[(*index)++] = (char) ('0' + (value % 10U));
}

static void append_signed5(char *buffer, uint8_t *index, int32_t value)
{
    uint32_t magnitude;
    if (value < 0) {
        buffer[(*index)++] = '-';
        magnitude = (uint32_t) (-value);
    } else {
        buffer[(*index)++] = '+';
        magnitude = (uint32_t) value;
    }
    append_unsigned5(buffer, index, magnitude);
}

static void format_mode(char *buffer, const TaskManager *manager)
{
    const char *status;
    uint8_t index = 0U;

    if (manager->selected_mode == TASK_MODE_Q3) {
        if (manager->q3.status == TASK_Q3_WAIT_DONE) {
            status = manager->q3.ack_received ? "ACK" : "RUN";
        } else if (manager->q3.status == TASK_Q3_DONE) {
            status = "DONE";
        } else if (manager->q3.status == TASK_Q3_REMOTE_ERROR) {
            status = "ERR";
        } else {
            status = "STOP";
        }
    } else if (manager->selected_mode == TASK_MODE_Q6) {
        if (manager->q6.state == Q6_WAIT_CAPTURE) {
            status = "CAP";
        } else if (manager->q6.state == Q6_WAIT_STOP) {
            status = "STOP";
        } else if (manager->q6.state == Q6_DONE) {
            status = "DONE";
        } else if (manager->q6.state == Q6_FAULT) {
            status = "ERR";
        } else if (manager->running) {
            status = "RUN";
        } else if (manager->finished) {
            status = "DONE";
        } else {
            status = "STOP";
        }
    } else if (!task_mode_is_available(manager->selected_mode)) {
        status = "WAIT";
    } else if (manager->running) {
        status = "RUN";
    } else if (manager->finished) {
        status = "DONE";
    } else {
        status = "STOP";
    }

    buffer[index++] = 'Q';
    buffer[index++] = ':';
    buffer[index++] = (char) ('0' + manager->selected_mode);
    buffer[index++] = ' ';
    while (*status != '\0') {
        buffer[index++] = *status++;
    }
    buffer[index] = '\0';
}

static void format_time(char *buffer, uint32_t elapsed_ms)
{
    uint32_t seconds = (elapsed_ms / 1000U) % 100U;
    uint32_t milliseconds = elapsed_ms % 1000U;

    buffer[0] = 'T';
    buffer[1] = ':';
    buffer[2] = (char) ('0' + (seconds / 10U));
    buffer[3] = (char) ('0' + (seconds % 10U));
    buffer[4] = '.';
    buffer[5] = (char) ('0' + (milliseconds / 100U));
    buffer[6] = (char) ('0' + ((milliseconds / 10U) % 10U));
    buffer[7] = (char) ('0' + (milliseconds % 10U));
    buffer[8] = '\0';
}

static void format_encoders(char *buffer)
{
    int32_t left;
    int32_t right;
    uint8_t index = 0U;

    encoder_get_counts(&left, &right);
    buffer[index++] = 'L';
    buffer[index++] = ':';
    append_signed5(buffer, &index, left);
    buffer[index++] = ' ';
    buffer[index++] = 'R';
    buffer[index++] = ':';
    append_signed5(buffer, &index, right);
    buffer[index] = '\0';
}

static void format_distance(char *buffer, const TaskManager *manager)
{
    uint8_t index = 0U;
    buffer[index++] = 'D';
    buffer[index++] = ':';
    append_unsigned5(buffer, &index, (uint32_t) encoder_average_abs_count());
    buffer[index++] = ' ';
    buffer[index++] = 'N';
    buffer[index++] = ':';
    buffer[index++] = (char) ('0' + manager->gray.active_count);
    buffer[index] = '\0';
}

void task_manager_render(const TaskManager *manager)
{
    char line[22];

    oled_clear_line(0U);
    format_mode(line, manager);
    oled_print(0U, 0U, line);

    oled_clear_line(2U);
    format_time(line, manager->elapsed_ms);
    oled_print(2U, 0U, line);

    oled_clear_line(4U);
    format_encoders(line);
    oled_print(4U, 0U, line);

    oled_clear_line(6U);
    format_distance(line, manager);
    oled_print(6U, 0U, line);
}
