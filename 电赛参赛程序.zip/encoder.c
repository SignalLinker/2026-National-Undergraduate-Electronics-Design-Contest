#include "encoder.h"

#include "ti_msp_dl_config.h"

static volatile int32_t g_left_count;
static volatile int32_t g_right_count;
static uint8_t g_left_previous;
static uint8_t g_right_previous;

static uint8_t encoder_left_state(void)
{
    uint32_t pins = DL_GPIO_readPins(
        GPIO_ENCODER_PORT, GPIO_ENCODER_E1A_PIN | GPIO_ENCODER_E1B_PIN);
    return (uint8_t) ((((pins & GPIO_ENCODER_E1B_PIN) != 0U) ? 2U : 0U) |
        (((pins & GPIO_ENCODER_E1A_PIN) != 0U) ? 1U : 0U));
}

static uint8_t encoder_right_state(void)
{
    uint32_t pins = DL_GPIO_readPins(
        GPIO_ENCODER_PORT, GPIO_ENCODER_E2A_PIN | GPIO_ENCODER_E2B_PIN);
    return (uint8_t) ((((pins & GPIO_ENCODER_E2B_PIN) != 0U) ? 2U : 0U) |
        (((pins & GPIO_ENCODER_E2A_PIN) != 0U) ? 1U : 0U));
}

static int8_t encoder_delta(uint8_t previous, uint8_t current)
{
    static const int8_t table[16] = {
        0, -1, 1, 0, 1, 0, 0, -1,
        -1, 0, 0, 1, 0, 1, -1, 0,
    };
    return table[((previous & 0x03U) << 2) | (current & 0x03U)];
}

void encoder_init(void)
{
    g_left_previous = encoder_left_state();
    g_right_previous = encoder_right_state();
    NVIC_EnableIRQ(GPIO_ENCODER_INT_IRQN);
}

void encoder_reset(void)
{
    __disable_irq();
    g_left_count = 0;
    g_right_count = 0;
    g_left_previous = encoder_left_state();
    g_right_previous = encoder_right_state();
    __enable_irq();
}

void encoder_get_counts(int32_t *left_count, int32_t *right_count)
{
    __disable_irq();
    *left_count = g_left_count;
    *right_count = g_right_count;
    __enable_irq();
}

int32_t encoder_average_abs_count(void)
{
    int32_t left;
    int32_t right;
    encoder_get_counts(&left, &right);
    left = (left < 0) ? -left : left;
    right = (right < 0) ? -right : right;
    return (left + right) / 2;
}

void GROUP1_IRQHandler(void)
{
    uint32_t status = DL_GPIO_getEnabledInterruptStatus(GPIO_ENCODER_PORT,
        GPIO_ENCODER_E1A_PIN | GPIO_ENCODER_E1B_PIN |
            GPIO_ENCODER_E2A_PIN | GPIO_ENCODER_E2B_PIN);

    if ((status & (GPIO_ENCODER_E1A_PIN | GPIO_ENCODER_E1B_PIN)) != 0U) {
        uint8_t state = encoder_left_state();
        g_left_count -= encoder_delta(g_left_previous, state);
        g_left_previous = state;
    }
    if ((status & (GPIO_ENCODER_E2A_PIN | GPIO_ENCODER_E2B_PIN)) != 0U) {
        uint8_t state = encoder_right_state();
        g_right_count += encoder_delta(g_right_previous, state);
        g_right_previous = state;
    }

    DL_GPIO_clearInterruptStatus(GPIO_ENCODER_PORT,
        GPIO_ENCODER_E1A_PIN | GPIO_ENCODER_E1B_PIN |
            GPIO_ENCODER_E2A_PIN | GPIO_ENCODER_E2B_PIN);
}
