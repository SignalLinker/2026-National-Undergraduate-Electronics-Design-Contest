#ifndef TASK_MANAGER_H
#define TASK_MANAGER_H

#include <stdbool.h>
#include <stdint.h>

#include "button.h"
#include "gray.h"
#include "launch_control.h"
#include "line_control.h"
#include "task_q2.h"
#include "task_q3.h"
#include "task_q4.h"
#include "task_q5.h"
#include "task_q6.h"

typedef struct {
    uint8_t selected_mode;
    uint8_t left_duty;
    uint8_t right_duty;
    uint32_t start_ms;
    uint32_t elapsed_ms;
    bool running;
    bool finished;
    bool active_high;
    GraySample gray;
    LaunchControlState launch;
    LineControlState line_control;
    TaskQ2State q2;
    TaskQ3State q3;
    TaskQ4State q4;
    TaskQ5State q5;
    TaskQ6State q6;
} TaskManager;

void task_manager_init(TaskManager *manager);
void task_manager_handle_buttons(TaskManager *manager,
    ButtonEvent select_event, ButtonEvent start_event);
void task_manager_update(TaskManager *manager, uint16_t elapsed_ms);
void task_manager_render(const TaskManager *manager);

#endif
