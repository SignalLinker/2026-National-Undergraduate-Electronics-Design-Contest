#ifndef GRAY_H
#define GRAY_H

#include <stdbool.h>
#include <stdint.h>

typedef struct {
    uint8_t raw;
    uint8_t active;
    uint8_t active_count;
    int16_t error;
    bool has_line;
} GraySample;

GraySample gray_scan(bool active_high);

#endif
