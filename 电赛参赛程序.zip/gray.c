#include "gray.h"

#include "ti_msp_dl_config.h"

static void gray_select_channel(uint8_t channel)
{
    uint32_t set_pins = 0U;
    uint32_t clear_pins =
        GPIO_GRAY_AD0_PIN | GPIO_GRAY_AD1_PIN | GPIO_GRAY_AD2_PIN;

    if ((channel & 0x01U) != 0U) {
        set_pins |= GPIO_GRAY_AD0_PIN;
    }
    if ((channel & 0x02U) != 0U) {
        set_pins |= GPIO_GRAY_AD1_PIN;
    }
    if ((channel & 0x04U) != 0U) {
        set_pins |= GPIO_GRAY_AD2_PIN;
    }
    if (set_pins != 0U) {
        DL_GPIO_setPins(GPIO_GRAY_PORT, set_pins);
    }
    DL_GPIO_clearPins(GPIO_GRAY_PORT, clear_pins & ~set_pins);
}

GraySample gray_scan(bool active_high)
{
    static const int8_t weights[8] = {-7, -5, -3, -1, 1, 3, 5, 7};
    GraySample sample = {0};
    int16_t sum = 0;

    for (uint8_t channel = 0U; channel < 8U; channel++) {
        gray_select_channel(channel);
        delay_cycles(8000U);
        if ((DL_GPIO_readPins(GPIO_GRAY_PORT, GPIO_GRAY_OUT_PIN) &
                GPIO_GRAY_OUT_PIN) != 0U) {
            sample.raw |= (uint8_t) (1U << channel);
        }
    }

    sample.active = active_high ? sample.raw : (uint8_t) ~sample.raw;
    for (uint8_t channel = 0U; channel < 8U; channel++) {
        if ((sample.active & (1U << channel)) != 0U) {
            sample.active_count++;
            sum += weights[channel];
        }
    }
    sample.has_line = sample.active_count != 0U;
    sample.error = sample.has_line ? (sum / sample.active_count) : 99;
    return sample;
}
