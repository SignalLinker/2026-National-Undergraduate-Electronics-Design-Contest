# 36_diansai_q6_gray_a_only


第5问保持原逻辑：灰度检测A点或达到里程保护值后减速停车。

第6问关闭里程保护停车，只在编码器达到A点检测使能距离后，
灰度同时检测到至少5路有效信号时确认A点、冻结计时、停车并向K230发送STOP。

本工程仅简化赛题第6问：

- 发送原协议 `START(6)`，不要求先收到 `STATE=9`。
- 第一帧合法 `STATE=1、VALID=1` 立即启动底盘。
- POSITION和ELAPSED不参与启动判断。
- 启动后5秒仍未锁点才显示ERR并发送STOP。
- 运行中的偶发丢帧和 `STATE=5` 不终止底盘循迹。
- 到A点或里程保护停车时发送STOP，不再因本地计时达到30秒提前停车。
- 第3、4、5问和全部循迹参数保持原工程配置。

Modular multi-task project based on the tested `10_diansai` hardware setup.

This project is copied from `30_diansai_q6_handshake`. It keeps the same
chassis line-following, curve smoothing, and K230 eight-byte UART protocol on
`PB6/PB7`.

The original curve behavior uses `18_diansai_q4_trim` as its baseline and smooths only
mid-curve correction changes. The first nonzero curve correction is applied
immediately, preserving curve entry. While the curve remains active, the
correction changes by at most 2 duty percentage points per update. Three
consecutive neutral frames end curve smoothing and restore direct straight
control. Existing trims, center deadband, launch guard, speed, stopping logic,
and dual-button controls are unchanged. While
the grayscale array is still over the wide A marker, line-error correction is
disabled. After five normal-line scans, correction ramps from 0% to 100% over
400 ms, preventing an asymmetric first sample from accelerating one wheel.

## Button

- `PB14` to GND, stopped press and release: select `Q:1` through `Q:5`.
- `PB21` to GND, long press: start the selected available task.
- Running `PB21` long press: emergency stop.
- `PB21` short press is ignored; `PB14` is ignored while running.
- `Q:1` implements requirement 2.
- `Q:2` implements requirement 3 through K230 UART.
- `Q:3` implements requirement 4: send K230 START(4), then run the A-to-B
  chassis stage.
- `Q:4` implements requirement 5: send K230 START(5), then run the one-lap
  chassis stage.
- `Q:5` implements requirement 6: send K230 START(6), then start the chassis
  on the first legal `STATE=1 VALID=1` frame.

## K230 UART

UART format is 115200 baud, 8 data bits, no parity, 1 stop bit, 3.3 V TTL.

| MSPM0G3507 | K230 communication UART | Direction |
|---|---|---|
| `PB6 / UART1_TX` | `RX` | MSPM0 to K230 |
| `PB7 / UART1_RX` | `TX` | K230 to MSPM0 |
| `GND` | `GND` | Common ground |

Frames are eight bytes:

```text
A5 5A TYPE DATA0 DATA1 DATA2 DATA3 CHECKSUM
```

`CHECKSUM` is XOR of bytes 0 through 6.

- Q:2 sends requirement 3 START: `A5 5A 10 03 00 00 00 EC`.
- Q:3 sends requirement 4 START once at task start:
  `A5 5A 10 04 00 00 00 EB`.
- Q:4 sends requirement 5 START once at task start:
  `A5 5A 10 05 00 00 00 EA`.
- Q:5 sends requirement 6 START once at task start:
  `A5 5A 10 06 00 00 00 E9`.
- STOP sends: `A5 5A 11 00 00 00 00 EE`.
- STATUS accepts `STATE=0..10`, so `STATE=9` and `STATE=10` are no longer
  discarded.
- Requirements 4 and 5 do not wait for K230 status before the chassis starts.
- Requirement 6 starts the MSPM0 30-second timer immediately on the button
  press. The chassis stays stopped until the first legal `STATE=1 VALID=1`
  frame arrives. `STATE=9`, POSITION and ELAPSED do not participate in the
  startup decision.

## Q6 handshake

Select `Q:5` for requirement 6.

1. Long press `PB21`: MSPM0 resets the local timer and sends
   `A5 5A 10 06 00 00 00 E9`.
2. MSPM0 ignores `STATE=9` and keeps the chassis stopped.
3. The first `STATE=1 VALID=1` frame starts the chassis line follower.
4. During driving, MSPM0 records `max(abs(position_x10 - target_x10))`.
5. When A is detected, MSPM0 stops the chassis, freezes the displayed time, and
   sends `A5 5A 11 00 00 00 00 EE`.
6. When K230 reports `STATE=7`, OLED shows `DONE`.

Fault handling:

- If no legal ready frame arrives within 5 seconds, stop the chassis, send
  STOP, and show `ERR`.
- During driving, intermittent missing frames and `STATE=5` do not stop line
  following.
- At A or the mileage safety stop, stop and send STOP. The local 30-second
  value is retained for scoring display and no longer forces an early stop.

Q1 uses 30% left and 33% right duty on centered straight sections to
compensate for the measured rightward drift. At average encoder count 40500,
it ramps down from 31% to 15% while continuing to follow the line, then brakes
when the grayscale sensor reaches A. Count 43000 is the missed-marker failsafe.

## Q3 display mode

Select `Q:3` and long press at A. The car ramps from 6% to 22%, follows the
line, and enters a line-following deceleration at count 9600. During the stop,
the base duty falls from 22% to 6% in 1% steps before the motors coast to rest.
Q3 does not apply a final short brake, reducing fore-aft steel-ball movement.
On a centered line, its right motor receives 2% more duty than its left motor.

## Q4 / Q5 display mode

Select `Q:4` and long press at A. The car ramps from 6% to 21% and follows the
line for one lap. A detection is armed after count 38000. At the next A marker,
it keeps following the line while ramping down to 6%, so the car passes A
before stopping. The displayed result time freezes when A is detected while
the soft stop continues. Acceleration uses 1% steps every 120 ms and
deceleration uses 1% steps every 100 ms. Count 44000 starts the same
deceleration if A is missed.
On a centered line at cruise, Q4 uses 20% left and 22% right duty.

Select `Q:5` for requirement 6. It uses the Q6 handshake above before starting
the same one-lap chassis speed and trim as `Q:4`.

## OLED

- Page 0: selected task and state.
- Page 2: elapsed time.
- Page 4: left and right encoder counts.
- Page 6: average distance count and active grayscale channel count.
