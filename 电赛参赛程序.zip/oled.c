#include "oled.h"

#include "ti_msp_dl_config.h"

#define OLED_ADDRESS 0x3CU
#define OLED_WIDTH 128U
#define OLED_PAGES 8U
#define OLED_PACKET_SIZE 8U

static bool i2c_write(const uint8_t *data, uint8_t length)
{
    uint32_t timeout = 100000U;

    while ((DL_I2C_getControllerStatus(I2C_INST) &
               DL_I2C_CONTROLLER_STATUS_IDLE) == 0U) {
        if (--timeout == 0U) {
            return false;
        }
    }

    DL_I2C_flushControllerTXFIFO(I2C_INST);
    DL_I2C_fillControllerTXFIFO(I2C_INST, data, length);
    DL_I2C_startControllerTransfer(
        I2C_INST, OLED_ADDRESS, DL_I2C_CONTROLLER_DIRECTION_TX, length);
    delay_cycles(64U);

    timeout = 100000U;
    while ((DL_I2C_getControllerStatus(I2C_INST) &
               DL_I2C_CONTROLLER_STATUS_BUSY) != 0U) {
        if (--timeout == 0U) {
            return false;
        }
    }
    return (DL_I2C_getControllerStatus(I2C_INST) &
               DL_I2C_CONTROLLER_STATUS_ERROR) == 0U;
}

static bool oled_command(uint8_t command)
{
    uint8_t packet[2] = {0x00U, command};
    return i2c_write(packet, sizeof(packet));
}

static bool oled_data(const uint8_t *data, uint8_t length)
{
    uint8_t packet[OLED_PACKET_SIZE];

    while (length > 0U) {
        uint8_t chunk = (length > (OLED_PACKET_SIZE - 1U))
                            ? (OLED_PACKET_SIZE - 1U)
                            : length;
        packet[0] = 0x40U;
        for (uint8_t i = 0U; i < chunk; i++) {
            packet[i + 1U] = data[i];
        }
        if (!i2c_write(packet, (uint8_t) (chunk + 1U))) {
            return false;
        }
        data += chunk;
        length -= chunk;
    }
    return true;
}

static void oled_set_cursor(uint8_t page, uint8_t column)
{
    (void) oled_command((uint8_t) (0xB0U | (page & 0x07U)));
    (void) oled_command((uint8_t) (column & 0x0FU));
    (void) oled_command((uint8_t) (0x10U | ((column >> 4) & 0x0FU)));
}

static const uint8_t *font5x7(char character)
{
    static const uint8_t blank[5] = {0, 0, 0, 0, 0};
    static const uint8_t colon[5] = {0, 0x36, 0x36, 0, 0};
    static const uint8_t minus[5] = {0x08, 0x08, 0x08, 0x08, 0x08};
    static const uint8_t plus[5] = {0x08, 0x08, 0x3E, 0x08, 0x08};
    static const uint8_t dot[5] = {0, 0x60, 0x60, 0, 0};
    static const uint8_t digits[10][5] = {
        {0x3E, 0x51, 0x49, 0x45, 0x3E},
        {0x00, 0x42, 0x7F, 0x40, 0x00},
        {0x42, 0x61, 0x51, 0x49, 0x46},
        {0x21, 0x41, 0x45, 0x4B, 0x31},
        {0x18, 0x14, 0x12, 0x7F, 0x10},
        {0x27, 0x45, 0x45, 0x45, 0x39},
        {0x3C, 0x4A, 0x49, 0x49, 0x30},
        {0x01, 0x71, 0x09, 0x05, 0x03},
        {0x36, 0x49, 0x49, 0x49, 0x36},
        {0x06, 0x49, 0x49, 0x29, 0x1E},
    };
    static const uint8_t letters[26][5] = {
        {0x7E, 0x11, 0x11, 0x11, 0x7E},
        {0x7F, 0x49, 0x49, 0x49, 0x36},
        {0x3E, 0x41, 0x41, 0x41, 0x22},
        {0x7F, 0x41, 0x41, 0x22, 0x1C},
        {0x7F, 0x49, 0x49, 0x49, 0x41},
        {0x7F, 0x09, 0x09, 0x09, 0x01},
        {0x3E, 0x41, 0x49, 0x49, 0x7A},
        {0x7F, 0x08, 0x08, 0x08, 0x7F},
        {0x00, 0x41, 0x7F, 0x41, 0x00},
        {0x20, 0x40, 0x41, 0x3F, 0x01},
        {0x7F, 0x08, 0x14, 0x22, 0x41},
        {0x7F, 0x40, 0x40, 0x40, 0x40},
        {0x7F, 0x02, 0x0C, 0x02, 0x7F},
        {0x7F, 0x04, 0x08, 0x10, 0x7F},
        {0x3E, 0x41, 0x41, 0x41, 0x3E},
        {0x7F, 0x09, 0x09, 0x09, 0x06},
        {0x3E, 0x41, 0x51, 0x21, 0x5E},
        {0x7F, 0x09, 0x19, 0x29, 0x46},
        {0x46, 0x49, 0x49, 0x49, 0x31},
        {0x01, 0x01, 0x7F, 0x01, 0x01},
        {0x3F, 0x40, 0x40, 0x40, 0x3F},
        {0x1F, 0x20, 0x40, 0x20, 0x1F},
        {0x3F, 0x40, 0x38, 0x40, 0x3F},
        {0x63, 0x14, 0x08, 0x14, 0x63},
        {0x07, 0x08, 0x70, 0x08, 0x07},
        {0x61, 0x51, 0x49, 0x45, 0x43},
    };

    if ((character >= '0') && (character <= '9')) {
        return digits[character - '0'];
    }
    if ((character >= 'a') && (character <= 'z')) {
        character = (char) (character - ('a' - 'A'));
    }
    if ((character >= 'A') && (character <= 'Z')) {
        return letters[character - 'A'];
    }
    if (character == ':') {
        return colon;
    }
    if (character == '-') {
        return minus;
    }
    if (character == '+') {
        return plus;
    }
    if (character == '.') {
        return dot;
    }
    return blank;
}

static void oled_put_character(char character)
{
    uint8_t glyph[6];
    const uint8_t *source = font5x7(character);
    for (uint8_t i = 0U; i < 5U; i++) {
        glyph[i] = source[i];
    }
    glyph[5] = 0U;
    (void) oled_data(glyph, sizeof(glyph));
}

void oled_print(uint8_t page, uint8_t column, const char *text)
{
    oled_set_cursor(page, column);
    while (*text != '\0') {
        oled_put_character(*text++);
    }
}

void oled_clear_line(uint8_t page)
{
    uint8_t zeros[OLED_PACKET_SIZE - 1U] = {0};
    oled_set_cursor(page, 0U);
    for (uint8_t column = 0U; column < OLED_WIDTH;
         column += sizeof(zeros)) {
        (void) oled_data(zeros, sizeof(zeros));
    }
}

static void oled_clear(void)
{
    for (uint8_t page = 0U; page < OLED_PAGES; page++) {
        oled_clear_line(page);
    }
}

bool oled_init(void)
{
    static const uint8_t commands[] = {
        0xAE, 0x20, 0x00, 0xB0, 0xC8, 0x00, 0x10, 0x40,
        0x81, 0x7F, 0xA1, 0xA6, 0xA8, 0x3F, 0xA4, 0xD3,
        0x00, 0xD5, 0x80, 0xD9, 0xF1, 0xDA, 0x12, 0xDB,
        0x40, 0x8D, 0x14, 0xAF,
    };

    delay_cycles(CPUCLK_FREQ / 10U);
    for (uint8_t i = 0U; i < sizeof(commands); i++) {
        if (!oled_command(commands[i])) {
            return false;
        }
    }
    oled_clear();
    return true;
}
