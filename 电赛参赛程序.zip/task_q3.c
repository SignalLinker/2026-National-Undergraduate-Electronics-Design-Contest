#include "task_q3.h"

#include "app_config.h"
#include "k230_link.h"

void task_q3_reset(TaskQ3State *state)
{
    state->status = TASK_Q3_IDLE;
    state->ack_received = false;
    state->status_received = false;
    state->start_attempts = 0U;
    state->last_status_ms = 0U;
    k230_link_reset();
}

void task_q3_start(TaskQ3State *state)
{
    k230_link_reset();
    state->ack_received = false;
    state->status_received = false;
    state->start_attempts = 1U;
    state->last_status_ms = 0U;
    state->status = TASK_Q3_WAIT_DONE;
    k230_link_send_q3_start();
}

void task_q3_cancel(TaskQ3State *state)
{
    state->status = TASK_Q3_IDLE;
    state->ack_received = false;
    state->status_received = false;
    state->start_attempts = 0U;
}

TaskQ3Status task_q3_update(TaskQ3State *state, uint32_t elapsed_ms)
{
    K230StatusFrame link_status;

    if (state->status != TASK_Q3_WAIT_DONE) {
        return state->status;
    }

    while (k230_link_poll_status(&link_status)) {
        state->status_received = true;
        state->last_status_ms = elapsed_ms;
        if ((link_status.state == K230_STATE_TO_POSITIVE) ||
            (link_status.state == K230_STATE_TO_NEGATIVE)) {
            state->ack_received = true;
        } else if (link_status.state == K230_STATE_DONE) {
            state->ack_received = true;
            state->status = TASK_Q3_DONE;
            return state->status;
        } else if ((link_status.state == K230_STATE_BALL_LOST) ||
            (link_status.state == K230_STATE_TIMEOUT) ||
            (link_status.state == K230_STATE_ABORTED) ||
            (link_status.state == K230_STATE_ERROR)) {
            state->status = TASK_Q3_REMOTE_ERROR;
            return state->status;
        } else if ((link_status.state == K230_STATE_HOLD_TARGET) &&
            link_status.valid) {
            state->status_received = true;
        }
    }

    if (!state->ack_received) {
        if ((state->start_attempts < Q3_START_MAX_ATTEMPTS) &&
            (elapsed_ms >=
                ((uint32_t) state->start_attempts * Q3_START_RETRY_MS))) {
            k230_link_send_q3_start();
            state->start_attempts++;
        } else if (elapsed_ms >= Q3_START_CONFIRM_TIMEOUT_MS) {
            state->status = TASK_Q3_REMOTE_ERROR;
        }
    } else if (state->status_received &&
        ((elapsed_ms - state->last_status_ms) > Q3_STATUS_OFFLINE_MS)) {
        state->status = TASK_Q3_REMOTE_ERROR;
    }
    return state->status;
}
