#ifndef K230_LINK_H
#define K230_LINK_H

#include <stdbool.h>
#include <stdint.h>

typedef enum {
    K230_STATE_IDLE = 0U,
    K230_STATE_HOLD_TARGET = 1U,
    K230_STATE_TO_POSITIVE = 2U,
    K230_STATE_TO_NEGATIVE = 3U,
    K230_STATE_DONE = 4U,
    K230_STATE_BALL_LOST = 5U,
    K230_STATE_TIMEOUT = 6U,
    K230_STATE_ABORTED = 7U,
    K230_STATE_ERROR = 8U,
    K230_STATE_CAPTURE_TARGET = 9U,
    K230_STATE_CAR_ONLY = 10U,
} K230State;

typedef struct {
    uint8_t state;
    bool valid;
    int16_t position_x10_cm;
    uint16_t elapsed_ms;
} K230StatusFrame;

void k230_link_reset(void);
void k230_link_send_task_start(uint8_t task_number);
void k230_link_send_q3_start(void);
void k230_link_send_stop(void);
bool k230_link_poll_status(K230StatusFrame *status);

#endif
