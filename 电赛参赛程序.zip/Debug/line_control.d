# FIXED

line_control.o: ../line_control.c ../line_control.h ../motor.h
../line_control.h:
../motor.h:
