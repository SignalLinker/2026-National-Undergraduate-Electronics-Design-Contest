################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"D:/ti/ccs2051/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"D:/tianmengxing/26H/codex/37_diansai_q2_stop_at_a" -I"D:/tianmengxing/26H/codex/37_diansai_q2_stop_at_a/Debug" -I"D:/ti/ccs2051/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/ti/ccs2051/mspm0_sdk_2_11_00_07/source" -g -Wall -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

build-1349937606: ../empty.syscfg
	@echo 'SysConfig - building file: "$<"'
	"D:/ti/ccs2051/sysconfig_1.26.2/sysconfig_cli.bat" -s "D:/ti/ccs2051/mspm0_sdk_2_11_00_07/.metadata/product.json" --script "D:/tianmengxing/26H/codex/37_diansai_q2_stop_at_a/empty.syscfg" -o "." --compiler ticlang
	@echo 'Finished building: "$<"'
	@echo ' '

device_linker.cmd: build-1349937606 ../empty.syscfg
device.opt: build-1349937606
device.cmd.genlibs: build-1349937606
ti_msp_dl_config.c: build-1349937606
ti_msp_dl_config.h: build-1349937606
Event.dot: build-1349937606

%.o: ./%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"D:/ti/ccs2051/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"D:/tianmengxing/26H/codex/37_diansai_q2_stop_at_a" -I"D:/tianmengxing/26H/codex/37_diansai_q2_stop_at_a/Debug" -I"D:/ti/ccs2051/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/ti/ccs2051/mspm0_sdk_2_11_00_07/source" -g -Wall -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

startup_mspm0g350x_ticlang.o: D:/ti/ccs2051/mspm0_sdk_2_11_00_07/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"D:/ti/ccs2051/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"D:/tianmengxing/26H/codex/37_diansai_q2_stop_at_a" -I"D:/tianmengxing/26H/codex/37_diansai_q2_stop_at_a/Debug" -I"D:/ti/ccs2051/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/ti/ccs2051/mspm0_sdk_2_11_00_07/source" -g -Wall -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


