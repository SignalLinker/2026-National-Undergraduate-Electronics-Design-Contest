################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
SYSCFG_SRCS += \
../empty.syscfg 

C_SRCS += \
../button.c \
../empty.c \
./ti_msp_dl_config.c \
D:/ti/ccs2051/mspm0_sdk_2_11_00_07/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c \
../encoder.c \
../gray.c \
../k230_link.c \
../launch_control.c \
../line_control.c \
../motor.c \
../oled.c \
../task_manager.c \
../task_q2.c \
../task_q3.c \
../task_q4.c \
../task_q5.c \
../task_q6.c \
../timebase.c 

GEN_CMDS += \
./device_linker.cmd 

GEN_FILES += \
./device_linker.cmd \
./device.opt \
./ti_msp_dl_config.c 

C_DEPS += \
./button.d \
./empty.d \
./ti_msp_dl_config.d \
./startup_mspm0g350x_ticlang.d \
./encoder.d \
./gray.d \
./k230_link.d \
./launch_control.d \
./line_control.d \
./motor.d \
./oled.d \
./task_manager.d \
./task_q2.d \
./task_q3.d \
./task_q4.d \
./task_q5.d \
./task_q6.d \
./timebase.d 

GEN_OPTS += \
./device.opt 

OBJS += \
./button.o \
./empty.o \
./ti_msp_dl_config.o \
./startup_mspm0g350x_ticlang.o \
./encoder.o \
./gray.o \
./k230_link.o \
./launch_control.o \
./line_control.o \
./motor.o \
./oled.o \
./task_manager.o \
./task_q2.o \
./task_q3.o \
./task_q4.o \
./task_q5.o \
./task_q6.o \
./timebase.o 

GEN_MISC_FILES += \
./device.cmd.genlibs \
./ti_msp_dl_config.h \
./Event.dot 

OBJS__QUOTED += \
"button.o" \
"empty.o" \
"ti_msp_dl_config.o" \
"startup_mspm0g350x_ticlang.o" \
"encoder.o" \
"gray.o" \
"k230_link.o" \
"launch_control.o" \
"line_control.o" \
"motor.o" \
"oled.o" \
"task_manager.o" \
"task_q2.o" \
"task_q3.o" \
"task_q4.o" \
"task_q5.o" \
"task_q6.o" \
"timebase.o" 

GEN_MISC_FILES__QUOTED += \
"device.cmd.genlibs" \
"ti_msp_dl_config.h" \
"Event.dot" 

C_DEPS__QUOTED += \
"button.d" \
"empty.d" \
"ti_msp_dl_config.d" \
"startup_mspm0g350x_ticlang.d" \
"encoder.d" \
"gray.d" \
"k230_link.d" \
"launch_control.d" \
"line_control.d" \
"motor.d" \
"oled.d" \
"task_manager.d" \
"task_q2.d" \
"task_q3.d" \
"task_q4.d" \
"task_q5.d" \
"task_q6.d" \
"timebase.d" 

GEN_FILES__QUOTED += \
"device_linker.cmd" \
"device.opt" \
"ti_msp_dl_config.c" 

C_SRCS__QUOTED += \
"../button.c" \
"../empty.c" \
"./ti_msp_dl_config.c" \
"D:/ti/ccs2051/mspm0_sdk_2_11_00_07/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c" \
"../encoder.c" \
"../gray.c" \
"../k230_link.c" \
"../launch_control.c" \
"../line_control.c" \
"../motor.c" \
"../oled.c" \
"../task_manager.c" \
"../task_q2.c" \
"../task_q3.c" \
"../task_q4.c" \
"../task_q5.c" \
"../task_q6.c" \
"../timebase.c" 

SYSCFG_SRCS__QUOTED += \
"../empty.syscfg" 


