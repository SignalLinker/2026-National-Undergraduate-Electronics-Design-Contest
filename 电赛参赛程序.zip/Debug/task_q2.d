# FIXED

task_q2.o: ../task_q2.c ../task_q2.h ../app_config.h
../task_q2.h:
../app_config.h:
