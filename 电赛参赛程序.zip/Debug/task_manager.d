# FIXED

task_manager.o: ../task_manager.c ../task_manager.h ../button.h ../gray.h \
 ../launch_control.h ../line_control.h ../task_q2.h ../task_q3.h \
 ../task_q4.h ../task_q5.h ../task_q6.h ../app_config.h ../encoder.h \
 ../k230_link.h ../motor.h ../oled.h ../timebase.h
../task_manager.h:
../button.h:
../gray.h:
../launch_control.h:
../line_control.h:
../task_q2.h:
../task_q3.h:
../task_q4.h:
../task_q5.h:
../task_q6.h:
../app_config.h:
../encoder.h:
../k230_link.h:
../motor.h:
../oled.h:
../timebase.h:
