# FIXED

task_q5.o: ../task_q5.c ../task_q5.h ../app_config.h
../task_q5.h:
../app_config.h:
