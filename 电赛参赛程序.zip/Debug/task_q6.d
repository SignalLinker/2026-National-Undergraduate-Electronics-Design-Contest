# FIXED

task_q6.o: ../task_q6.c ../task_q6.h ../app_config.h ../k230_link.h
../task_q6.h:
../app_config.h:
../k230_link.h:
