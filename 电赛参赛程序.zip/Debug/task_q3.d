# FIXED

task_q3.o: ../task_q3.c ../task_q3.h ../app_config.h ../k230_link.h
../task_q3.h:
../app_config.h:
../k230_link.h:
