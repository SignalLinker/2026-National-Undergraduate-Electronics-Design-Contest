/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)


#define CPUCLK_FREQ                                                     32000000



/* Defines for PWM_MOTOR */
#define PWM_MOTOR_INST                                                     TIMG0
#define PWM_MOTOR_INST_IRQHandler                               TIMG0_IRQHandler
#define PWM_MOTOR_INST_INT_IRQN                                 (TIMG0_INT_IRQn)
#define PWM_MOTOR_INST_CLK_FREQ                                         32000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_MOTOR_C0_PORT                                             GPIOA
#define GPIO_PWM_MOTOR_C0_PIN                                     DL_GPIO_PIN_12
#define GPIO_PWM_MOTOR_C0_IOMUX                                  (IOMUX_PINCM34)
#define GPIO_PWM_MOTOR_C0_IOMUX_FUNC                 IOMUX_PINCM34_PF_TIMG0_CCP0
#define GPIO_PWM_MOTOR_C0_IDX                                DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_MOTOR_C1_PORT                                             GPIOA
#define GPIO_PWM_MOTOR_C1_PIN                                     DL_GPIO_PIN_13
#define GPIO_PWM_MOTOR_C1_IOMUX                                  (IOMUX_PINCM35)
#define GPIO_PWM_MOTOR_C1_IOMUX_FUNC                 IOMUX_PINCM35_PF_TIMG0_CCP1
#define GPIO_PWM_MOTOR_C1_IDX                                DL_TIMER_CC_1_INDEX




/* Defines for I2C */
#define I2C_INST                                                            I2C0
#define I2C_INST_IRQHandler                                      I2C0_IRQHandler
#define I2C_INST_INT_IRQN                                          I2C0_INT_IRQn
#define I2C_BUS_SPEED_HZ                                                  400000
#define GPIO_I2C_SDA_PORT                                                  GPIOA
#define GPIO_I2C_SDA_PIN                                          DL_GPIO_PIN_28
#define GPIO_I2C_IOMUX_SDA                                        (IOMUX_PINCM3)
#define GPIO_I2C_IOMUX_SDA_FUNC                         IOMUX_PINCM3_PF_I2C0_SDA
#define GPIO_I2C_SCL_PORT                                                  GPIOA
#define GPIO_I2C_SCL_PIN                                          DL_GPIO_PIN_31
#define GPIO_I2C_IOMUX_SCL                                        (IOMUX_PINCM6)
#define GPIO_I2C_IOMUX_SCL_FUNC                         IOMUX_PINCM6_PF_I2C0_SCL


/* Defines for UART_K230 */
#define UART_K230_INST                                                     UART1
#define UART_K230_INST_FREQUENCY                                        32000000
#define UART_K230_INST_IRQHandler                               UART1_IRQHandler
#define UART_K230_INST_INT_IRQN                                   UART1_INT_IRQn
#define GPIO_UART_K230_RX_PORT                                             GPIOB
#define GPIO_UART_K230_TX_PORT                                             GPIOB
#define GPIO_UART_K230_RX_PIN                                      DL_GPIO_PIN_7
#define GPIO_UART_K230_TX_PIN                                      DL_GPIO_PIN_6
#define GPIO_UART_K230_IOMUX_RX                                  (IOMUX_PINCM24)
#define GPIO_UART_K230_IOMUX_TX                                  (IOMUX_PINCM23)
#define GPIO_UART_K230_IOMUX_RX_FUNC                   IOMUX_PINCM24_PF_UART1_RX
#define GPIO_UART_K230_IOMUX_TX_FUNC                   IOMUX_PINCM23_PF_UART1_TX
#define UART_K230_BAUD_RATE                                             (115200)
#define UART_K230_IBRD_32_MHZ_115200_BAUD                                   (17)
#define UART_K230_FBRD_32_MHZ_115200_BAUD                                   (23)





/* Port definition for Pin Group GPIO_KEYS */
#define GPIO_KEYS_PORT                                                   (GPIOB)

/* Defines for USER_KEY: GPIOB.21 with pinCMx 49 on package pin 20 */
#define GPIO_KEYS_USER_KEY_PIN                                  (DL_GPIO_PIN_21)
#define GPIO_KEYS_USER_KEY_IOMUX                                 (IOMUX_PINCM49)
/* Defines for SELECT_KEY: GPIOB.14 with pinCMx 31 on package pin 2 */
#define GPIO_KEYS_SELECT_KEY_PIN                                (DL_GPIO_PIN_14)
#define GPIO_KEYS_SELECT_KEY_IOMUX                               (IOMUX_PINCM31)
/* Defines for AIN2: GPIOB.19 with pinCMx 45 on package pin 16 */
#define GPIO_MOTOR_DIR_AIN2_PORT                                         (GPIOB)
#define GPIO_MOTOR_DIR_AIN2_PIN                                 (DL_GPIO_PIN_19)
#define GPIO_MOTOR_DIR_AIN2_IOMUX                                (IOMUX_PINCM45)
/* Defines for AIN1: GPIOB.17 with pinCMx 43 on package pin 14 */
#define GPIO_MOTOR_DIR_AIN1_PORT                                         (GPIOB)
#define GPIO_MOTOR_DIR_AIN1_PIN                                 (DL_GPIO_PIN_17)
#define GPIO_MOTOR_DIR_AIN1_IOMUX                                (IOMUX_PINCM43)
/* Defines for BIN1: GPIOA.16 with pinCMx 38 on package pin 9 */
#define GPIO_MOTOR_DIR_BIN1_PORT                                         (GPIOA)
#define GPIO_MOTOR_DIR_BIN1_PIN                                 (DL_GPIO_PIN_16)
#define GPIO_MOTOR_DIR_BIN1_IOMUX                                (IOMUX_PINCM38)
/* Defines for BIN2: GPIOB.24 with pinCMx 52 on package pin 23 */
#define GPIO_MOTOR_DIR_BIN2_PORT                                         (GPIOB)
#define GPIO_MOTOR_DIR_BIN2_PIN                                 (DL_GPIO_PIN_24)
#define GPIO_MOTOR_DIR_BIN2_IOMUX                                (IOMUX_PINCM52)
/* Port definition for Pin Group GPIO_ENCODER */
#define GPIO_ENCODER_PORT                                                (GPIOA)

/* Defines for E1A: GPIOA.25 with pinCMx 55 on package pin 26 */
// pins affected by this interrupt request:["E1A","E1B","E2A","E2B"]
#define GPIO_ENCODER_INT_IRQN                                   (GPIOA_INT_IRQn)
#define GPIO_ENCODER_INT_IIDX                   (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define GPIO_ENCODER_E1A_IIDX                               (DL_GPIO_IIDX_DIO25)
#define GPIO_ENCODER_E1A_PIN                                    (DL_GPIO_PIN_25)
#define GPIO_ENCODER_E1A_IOMUX                                   (IOMUX_PINCM55)
/* Defines for E1B: GPIOA.14 with pinCMx 36 on package pin 7 */
#define GPIO_ENCODER_E1B_IIDX                               (DL_GPIO_IIDX_DIO14)
#define GPIO_ENCODER_E1B_PIN                                    (DL_GPIO_PIN_14)
#define GPIO_ENCODER_E1B_IOMUX                                   (IOMUX_PINCM36)
/* Defines for E2A: GPIOA.26 with pinCMx 59 on package pin 30 */
#define GPIO_ENCODER_E2A_IIDX                               (DL_GPIO_IIDX_DIO26)
#define GPIO_ENCODER_E2A_PIN                                    (DL_GPIO_PIN_26)
#define GPIO_ENCODER_E2A_IOMUX                                   (IOMUX_PINCM59)
/* Defines for E2B: GPIOA.27 with pinCMx 60 on package pin 31 */
#define GPIO_ENCODER_E2B_IIDX                               (DL_GPIO_IIDX_DIO27)
#define GPIO_ENCODER_E2B_PIN                                    (DL_GPIO_PIN_27)
#define GPIO_ENCODER_E2B_IOMUX                                   (IOMUX_PINCM60)
/* Port definition for Pin Group GPIO_GRAY */
#define GPIO_GRAY_PORT                                                   (GPIOB)

/* Defines for AD0: GPIOB.0 with pinCMx 12 on package pin 47 */
#define GPIO_GRAY_AD0_PIN                                        (DL_GPIO_PIN_0)
#define GPIO_GRAY_AD0_IOMUX                                      (IOMUX_PINCM12)
/* Defines for AD1: GPIOB.1 with pinCMx 13 on package pin 48 */
#define GPIO_GRAY_AD1_PIN                                        (DL_GPIO_PIN_1)
#define GPIO_GRAY_AD1_IOMUX                                      (IOMUX_PINCM13)
/* Defines for AD2: GPIOB.15 with pinCMx 32 on package pin 3 */
#define GPIO_GRAY_AD2_PIN                                       (DL_GPIO_PIN_15)
#define GPIO_GRAY_AD2_IOMUX                                      (IOMUX_PINCM32)
/* Defines for OUT: GPIOB.16 with pinCMx 33 on package pin 4 */
#define GPIO_GRAY_OUT_PIN                                       (DL_GPIO_PIN_16)
#define GPIO_GRAY_OUT_IOMUX                                      (IOMUX_PINCM33)


/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_PWM_MOTOR_init(void);
void SYSCFG_DL_I2C_init(void);
void SYSCFG_DL_UART_K230_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
