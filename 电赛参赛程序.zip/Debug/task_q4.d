# FIXED

task_q4.o: ../task_q4.c ../task_q4.h ../app_config.h ../encoder.h
../task_q4.h:
../app_config.h:
../encoder.h:
