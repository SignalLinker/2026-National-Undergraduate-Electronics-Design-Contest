# FIXED

launch_control.o: ../launch_control.c ../launch_control.h ../app_config.h
../launch_control.h:
../app_config.h:
