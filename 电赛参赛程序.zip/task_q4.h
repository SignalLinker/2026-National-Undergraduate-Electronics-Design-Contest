#ifndef TASK_Q4_H
#define TASK_Q4_H

#include <stdbool.h>
#include <stdint.h>

typedef struct {
    uint16_t ramp_ms;
    uint8_t base_duty;
    bool decelerating;
} TaskQ4State;

void task_q4_reset(TaskQ4State *state);
bool task_q4_update(TaskQ4State *state, uint16_t elapsed_ms);

#endif
