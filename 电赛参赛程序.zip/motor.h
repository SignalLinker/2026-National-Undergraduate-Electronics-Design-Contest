#ifndef MOTOR_H
#define MOTOR_H

#include <stdint.h>

void motor_stop(void);
void motor_drive_forward(uint8_t left_duty, uint8_t right_duty);
void motor_short_brake(uint8_t duty_percent, uint32_t brake_ms);
void motor_soft_stop(uint8_t left_duty, uint8_t right_duty,
    uint8_t step_percent, uint32_t step_ms, uint8_t brake_duty,
    uint32_t brake_ms);

#endif
